<?php
     //Include condtants.php file here.
     include('../config/constants.php'); 

     //1.get the id of admin to be deleted.
     $id = $_GET['id'];
 
     //2.create sql query to delete admin.
     $sql = "DELETE FROM tbl_order WHERE id=$id";
 
     //execute query.
     $res = mysqli_query($conn,$sql);
 
     if($res==true)
     {
         //echo "Admin Deleted";
         //create session variable to display the massage.
         $_SESSION['delete'] = "<div class='success'>Admin Deleted Successfully</div>";
         //redirect the manage admin page 
         header('location:'.SITEURL.'admin/manage-order.php');
     }
     else{
         //echo "Fail to delete admin";
         $_SESSION['delete'] = "<div class='error'>Fail to delete admin. Try Again Later</div>";
         header('location:'.SITEURL.'admin/manage-order.php');
     }
 
     //3.redirect to manage admin page with manage(success/manage) 
?>