<?php include("partials/menu.php") ?>

<div class="main-content">
<div class="wrapper">
            <h1>Manage Order</h1>   
            
            
            <table class = "tbl-full">
                <tr>
                    <th>S.R.</th>
                    <th>Customer Name</th>
                    <th>Customer Contact</th>
                    <th>Action</th>
                </tr>
                <?php 
                    $sql ="SELECT*FROM tbl_order";
                    //execute the query
                    $res = mysqli_query($conn,$sql);

                    if ($res == TRUE)
                    {
                        $count = mysqli_num_rows($res) ;

                        $sn=1; //Creat a variable and Assign the value

                        if($count>0)
                        {
                            while($rows=mysqli_fetch_assoc($res))
                            {
                                $id= $rows['id'];
                                $customer_name= $rows['customer_name'];
                                $customer_contact= $rows['customer_contact'];

                                ?>
                                     
                                    <tr>
                                        <td><?php echo $sn++; ?></td>
                                        <td><?php echo $customer_name; ?></td>
                                        <td><?php echo $customer_contact; ?></td>
                                        <td>
                                            
                                            <a href="<?php echo SITEURL; ?>admin/delete-order.php?id=<?php echo $id; ?>" class="btn-danger" >Delete order</a>
                                        </td>
                                    </tr>
                                <?php     
                                     
                            }

                        }
                        else
                        {

                        }
                    }
                ?>
            </table>
        </div>

</div>

<?php include("partials/footer.php") ?>