<?php include("partials/menu.php") ?>

<div class="main-content">
<div class="wrapper">
            <h1>Manage Food</h1>   
            
            <br>
            <!-- Button to add Admin -->
            <br>
            <a href="#" class="btn-primary">Add Food</a>
            <br>
            <br>  <br>
            <table class = "tbl-full">
                <tr>
                    <th>S.R.</th>
                    <th>Full Name</th>
                    <th>Username</th>
                    <th>Action</th>
                </tr>
                <tr>
                    <td>1.</td>
                    <td>Ashutosh parashari</td>
                    <td>Ashutosh parashari</td>
                    <td>
                        <a href="#" class="btn-secondary" >Update Food</a>
                        <a href="#" class="btn-danger" >Delete Food</a>
                    </td>
                </tr>

                <tr>
                    <td>2.</td>
                    <td>Ashutosh parashari</td>
                    <td>Ashutosh parashari</td>
                    <td>
                        <a href="#" class="btn-secondary" >Update Food</a>
                        <a href="#" class="btn-danger" >Delete Food</a>
                    </td>
                </tr>

                <tr>
                    <td>3.</td>
                    <td>Ashutosh parashari</td>
                    <td>Ashutosh parashari</td>
                    <td>
                        <a href="#" class="btn-secondary" >Update Food</a>
                        <a href="#" class="btn-danger" >Delete Food</a>
                    </td>
                </tr>
            </table>
        </div>

</div>

<?php include("partials/footer.php") ?>