 <!-- footer sec.start -->
 <div class="footer">
    <div class="wrapper">
            <p class = "text-center">2024 All rights reserved, some Grocery. Developed by - <a href="#"> Ashutosh kumar Parashari.</a></p>    
        </div>
    </div>
    <!-- footer sec. end -->
</body>
</html>