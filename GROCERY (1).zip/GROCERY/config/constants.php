<?php
    //start session
    session_start();

    define('SITEURL','http://localhost/GROCERY/');
    define('LOCALHOST','localhost');
    define('DB_USERNAME','root');
    define('DB_PASSWORD','');
    define('DB_NAME','grocery-order');

    $conn = mysqli_connect(LOCALHOST,DB_USERNAME,DB_PASSWORD) or die(mysqli_error($conn)); //database connection
    $db_select = mysqli_select_db($conn, 'grocery-order') or die(mysqli_error($conn));    //selecting database
    
?>