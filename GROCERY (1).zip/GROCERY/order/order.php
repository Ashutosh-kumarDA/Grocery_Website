<?php
include('../config/constants.php'); 

$foodName="Potato";
$price = "Rs.50";
$qty = $_POST["qty"];
$cName = $_POST["full-name"];
$cEmail= $_POST["email"];
$cContact = $_POST["contact"];
$cAddress = $_POST["address"];

$total = 50 * $qty;

$d = date("Y-m-d h:i:s");





$sql = "INSERT INTO `tbl_order` ( `item`, `price`, `qty`, `total`, `order_date`, `status`, 
`customer_name`, `customer_contact`, `customer_email`, `customer_address`) 
VALUES ( '$foodName', '$price', '$qty', '$total', '$d',
 'process', '$cName', '$cContact', '$cEmail', '$cAddress')";

if(mysqli_query($conn, $sql)){
    echo "Order Placed";
    header("Location: ../order.php?order-placed");
}


?>